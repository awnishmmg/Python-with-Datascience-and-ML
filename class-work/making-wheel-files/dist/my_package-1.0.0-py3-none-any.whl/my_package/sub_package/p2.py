
def dance():
    print('I will dance')

def sing():
    print('I will sing')
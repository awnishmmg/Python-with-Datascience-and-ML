
def wish():
    print('hello world')

